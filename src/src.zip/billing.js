import React , {useState, useEffect} from 'react';
import {useParams} from 'react-router-dom';
import axios from 'axios';
const Billing =() =>{
const{userid} = useParams();
const[bookinginfo , updateInfo] = useState([]);
const getData=()=>{
    let input=new FormData();
    input.append("bookingid",userid);
    let url="https://www.firstenquiry.com/api/react/hotel/room.php";
    axios.post(url,input).then(response=>{
        if(response.data.length>0){
            updateInfo(response.data);
        }
    })
}
useEffect(()=>{
    getData();

},[true])
        
        if(bookinginfo.length>0){
           return <div className="container mt-4">
                        <div className="row">
                            <div className="col-lg-1"></div>
                            <div className="col-lg-10 border p-2 rounded">
                        <h3 className="text-center">Customer Billing</h3>
                        <div className="row mt-3">
                            <div className="col-md-4">Name : Ramesh</div>
                            <div className="col-md-4">Mobile : 9876543210</div>
                            <div className="col-md-4">E-Mail : abc@gmail.com</div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-4">Address : Marathalli</div>
                            <div className="col-md-4">Id Proof : 12345</div>
                            <div className="col-md-4">Room No : 123456</div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-3">No of days : 3</div>
                            <div className="col-md-3">Booking Date : 7/8/2021 </div>
                            <div className="col-md-3">Paid : 3000</div>
                            <div className="col-md-3">Due : 5000</div>
                        </div>
                        <div className="row mt-3">
                            <div className="col-md-12 text-center">
                                <button className="btn btn-primary">Pay & Exit </button>
                            </div>
                        </div>
                        </div>
                        <div className="col-lg-1"></div>
                        </div>
                    </div>
            }else{
                return(
                    <h2 className="text-center text-warning">Please Wait Processing....</h2>    
                );
            }
}
export default Billing;